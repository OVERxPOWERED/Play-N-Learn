
"use client";
import { motion } from "motion/react";
import { useState, useEffect, MutableRefObject, useRef } from "react";

interface blockProps {
    x?: number;
    y?: number;
    playerState?: MutableRefObject<{
        isJumping: boolean;
        playerXpos: number;
    }>;
}

export default function Block({ x = 0, y = 0, playerState }: blockProps) {
    const [wh, setwh] = useState(0);
    const [ww, setww] = useState(0);
    const [realisHit, setrealIsHit] = useState(false);
    const [isHit, setIsHit] = useState(false);

    const previousJumpState = useRef(false);

    useEffect(() => {
        setwh(window.innerHeight / 2);
        setww(window.innerWidth / 2);
    }, []);

    // 2. The Game Loop: Constantly checking the player's ref without causing lag
    useEffect(() => {
        let animationFrameId: number;
const checkCollision = () => {
            if (playerState && playerState.current) {
                const { isJumping, playerXpos } = playerState.current;

                if (isJumping && !previousJumpState.current) {
                    
                    // 1. Define the Player's Hitbox Width
                    // (Assuming player is roughly 5% wide based on your movement logic. 
                    // Tweak this number if Mario is wider or thinner!)
                    const playerWidth = 1; 
                    const playerLeftEdge = playerXpos;
                    const playerRightEdge = playerXpos + playerWidth;

                    // 2. Define the Block's Hitbox boundaries
                    // (x is the center. Left block goes from x-6 to x. Right block goes from x to x+6)
                    const blockHalfWidth = 4;
                    const leftBrickStart = x - blockHalfWidth;
                    const center = x;
                    const rightBrickEnd = x + blockHalfWidth;

                    // 3. The Overlap Math
                    // Does the player's right shoulder pass the brick's left edge, 
                    // AND does the player's left shoulder pass before the brick's right edge?
                    const touchingLeftHalf = (playerRightEdge >= leftBrickStart) && (playerLeftEdge <= center);
                    const touchingRightHalf = (playerRightEdge >= center) && (playerLeftEdge <= rightBrickEnd);

                    // 4. Independent triggers (NO "else if" here!)
                    if (touchingLeftHalf) {
                        setTimeout(() => setIsHit(true), 150);
                    } 
                    
                    // Because this is a separate "if", hitting the middle triggers BOTH!
                    if (touchingRightHalf) {
                        setTimeout(() => setrealIsHit(true), 150); 
                    }
                }

                previousJumpState.current = isJumping;
            }

            animationFrameId = requestAnimationFrame(checkCollision);
        };

        animationFrameId = requestAnimationFrame(checkCollision);
        return () => cancelAnimationFrame(animationFrameId);
    }, [playerState, x]);

    return (
        <motion.div 
            id="block" 
            className="h-16 w-32 lg:h-20 lg:w-40 absolute flex cursor-pointer -translate-x-1/2 -translate-y-1/2 z-10" 
            style={{
                top: `${y}%`,
                left: `${x}%`
            }}
        >
            {/* LEFT HALF (Demo) */}
            <motion.div 
                id="demo" 
                className="h-full w-[50%] relative overflow-hidden"
                animate={isHit ? { y: [0, -30, 0] } : { y: 0 }}
                transition={{ duration: 0.3, ease: "anticipate" }}
                onAnimationComplete={() => setIsHit(false)}
            >
                <img 
                    src="/brick.png" 
                    alt="Brick left half" 
                    className="w-full h-full object-cover pointer-events-none"
                />
            </motion.div>
            
            {/* RIGHT HALF (Real) */}
            <motion.div 
                id="real"
                className="h-full w-[50%] relative overflow-hidden" 
                animate={realisHit ? { y: [0, -30, 0] } : { y: 0 }}
                transition={{ duration: 0.3, ease: "anticipate" }}
                onAnimationComplete={() => setrealIsHit(false)}
            >
                <img 
                    src="/block.png" 
                    alt="Block right half" 
                    className="w-full h-full object-cover pointer-events-none"
                />
            </motion.div>
        </motion.div>
    );
}