'use client'
import { useState, useEffect, useRef } from 'react'
import Player from './Player'
import Block from './Block'
import { pre } from 'motion/react-client'

export default function Environment() {
    const worldRef = useRef<HTMLDivElement>(null)

    // playerY is now an OFFSET. 
    // 0 = standing on the ground. -20 = 20vh in the air.
    const [playerX, setPlayerX] = useState(5)
    const [playerY, setPlayerY] = useState(0)

    const [blockX, setBlockX] = useState(50)
    const [blockY, setBlockY] = useState(20)

    const playerState = useRef({
        isJumping: false,
        playerXpos: 0
    })

    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            if (e.key === 'ArrowLeft') {
                setPlayerX((prevX) => {
                    if (prevX > 0) {
                        playerState.current.playerXpos = prevX - 5;
                        return prevX - 5
                    }
                    else {
                        playerState.current.playerXpos = prevX;
                        return prevX;
                    }
                });
            }
            if (e.key === 'ArrowRight') {
                setPlayerX((prevX) => {
                    if (prevX > 0) {
                        playerState.current.playerXpos = prevX + 5;
                        return prevX + 5
                    }
                    else {
                        playerState.current.playerXpos = prevX;
                        return prevX;
                    }
                });
            }

            if ((e.key === 'ArrowUp' || e.code === 'Space') && !(playerState.current.isJumping)) {

                playerState.current.isJumping = true;

                setPlayerY(-20);

                setTimeout(() => {
                    setPlayerY(0);
                }, 300);

                setTimeout(() => {
                    playerState.current.isJumping = false;
                }, 600);
            }
        };

        document.addEventListener('keydown', handleKeyDown);
        return () => {
            document.removeEventListener('keydown', handleKeyDown);
        };
    }, []);

    return (
        <div ref={worldRef} id='world' className='flex flex-col h-screen w-screen overflow-hidden relative'>
            <Player xPos={playerX} yPos={playerY} />
            <Block x={blockX} y={blockY} playerState={playerState} />

            <div
                style={{ backgroundImage: "url('/sky.png')" }} // Just use the string path
                id="sky"
                className="w-full h-[60%] bg-sky-500 bg-no-repeat bg-cover bg-center"
            ></div>
            <div id="ground" className="w-full h-[40%] bg-green-500"></div>
        </div>
    )
}