'use client';
import { useRef } from 'react';
import gsap from 'gsap'
import { useGSAP } from '@gsap/react';

gsap.registerPlugin(useGSAP);

interface PlayerProps {
    xPos: number;
    yPos: number;
}

export default function Player({ xPos = 0, yPos = 0 }: PlayerProps) {
    const playerRef = useRef<HTMLDivElement>(null);

    useGSAP(() => {
        gsap.to(playerRef.current, {
            x: `${xPos}vw`,
            y: `${yPos}vh`, // y is now an offset relative to the bottom-[40%] starting point
            duration: 0.2,
            ease: "power1.out"
        })
    }, { 
        dependencies: [xPos, yPos]
    })

    return (
        <div 
            ref={playerRef}
            // 1. absolute bottom-[40%] left-0 pins the feet exactly to the ground line
            // 2. You can use standard responsive classes now! (e.g., w-12 h-20 for mobile, lg:w-20 lg:h-32 for large screens)
            className="bg-black absolute bottom-[40%] left-0 w-12 h-20 lg:w-24 lg:h-40"
        >
            {/* We will put the character images inside here later */}
        </div>
    );
}